cancel <-
function (...){
    xx <<- xx.safe
#     meta <<- meta.safe
    numbs <<- numbs.safe
    hom <<- hom.safe
    tkrreplot(img)
}
